# cheksiz.AI

Bir nechta bepul AI API'ni zanjirga ulaydi. Biri limitga tushsa, suhbat tarixi bilan keyingisiga o'tadi.

## Kompyuterda sinash
    pip install -r requirements.txt
    cp .env.example .env     # kalitlarni to'ldiring
    # Windows: set o'zgaruvchilarni qo'lda yoki `pip install python-dotenv` + `from dotenv import load_dotenv; load_dotenv()`
    python app.py            # http://localhost:5000

## Render'ga chiqarish
1. Papkani GitHub'ga yuklang (.env fayl yuklanmasin).
2. render.com > New > Blueprint (yoki Web Service) > repo'ni tanlang.
3. Environment bo'limida ACCESS_PASSWORD va olgan kalitlaringizni kiriting.
4. Deploy. Saytga kirganda parol so'raladi.
